#include "widget.h"
#include <QPainter>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{}

Widget::~Widget() = default;

void Widget::paintEvent(QPaintEvent *event) {
    QPainter painter(this);   // 创建在widget上的画笔,并将其激活

    // 设置画笔颜色
    painter.setPen(QColor(0, 160, 230));

    // 设置字体：思源黑体、点大小50、斜体
    QFont font;
    // font.setFamily("FZLanTingHei-R-GBK");
    font.setFamily("Noto Sans CJK SC");
    font.setPointSize(50);
    font.setItalic(true);
    painter.setFont(font);

    // 绘制文本
    painter.drawText(rect(), Qt::AlignCenter, "2D drawing");
    painter.drawRect(200, 50, 160, 100);

    // 矩形
    QRectF rect(90.0, 90.0, 80.0, 90.0);
    // 起始角度
    int startAngle = 30 * 16;
    // 跨越度数
    int spanAngle = 120 * 16;
    // 绘制弧线
    painter.drawArc(rect, startAngle, spanAngle);

    // 绘制椭圆
    painter.drawEllipse(QPointF(120, 60), 50, 20);

    // 设置画刷颜色
    painter.setBrush(QColor(255, 0, 0));

    // 绘制圆
    painter.drawEllipse(QPointF(320, 400), 40, 40);

    QWidget::paintEvent(event);
    // 函数返回后，画笔会销毁，销毁时会自动结束与widget(QPaintDevice)的关联
}
