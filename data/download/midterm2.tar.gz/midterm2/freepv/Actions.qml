/*  There are all actions's UIs in the freepv app.
 *  Author: stardust
 *  Data: 2026-06-01
**/
import QtQuick
import QtQuick.Controls


Item {
    property alias open: _open

    property alias about: _about
    property alias exit: _exit

    Action {
        id: _open
        text: qsTr("&OpenFile...")
        icon.name: "document-open"
        shortcut: "StandardKey.Open"
    }

    Action {
        id: _exit
        text: qsTr("E&xit")
        icon.name: "application-exit"
    }


    Action {
        id: _about
        text: qsTr("&About")
        icon.name: "help-about"
    }

}
