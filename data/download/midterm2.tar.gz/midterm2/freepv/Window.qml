/* Freepv is a free picture viewer.
 * Distributed under GPL, Version 3.0.
 * The file defines the appwindow of freepv, and setts up all UIs' logic, except the content's.
 *  Author: stardust
 *  Data: 2026-06-01
**/
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import "freepv.js" as AppController

ApplicationWindow{
    id: window
    visible: true
    width: 1024
    height: 768

    property alias dialogs: content.dialogs
    property alias singleView: content.singleView
    property alias gridView: content.gridView

    menuBar: MenuBar{
        id: menuBar

        Menu{
            title: qsTr("&File")
            MenuItem{action: actions.open}
        }

        Menu {
            title: qsTr("&Help")
            MenuItem{action: actions.about}
        }
    }

    header: ToolBar {
        id:toolBar
        RowLayout{
            ToolButton{ action: actions.open }
            ToolButton{ action: actions.about }
        }
    }

    Actions{
        id:actions
        open.onTriggered: AppController.open()
        about.onTriggered: AppController.about()
    }

    Content{
        id:content
        anchors.fill: parent
    }

    Component.onCompleted: {
        AppController.init()
    }

}
