function init() {

}

function open() {
    dialogs.fileOpen.open()
    dialogs.fileOpen.accepted.connect(
                ()=>{
                    singleView.source = dialogs.fileOpen.selectedFile
                    singleView.z=1
                })
}

function about() {
    dialogs.about.open()

}

