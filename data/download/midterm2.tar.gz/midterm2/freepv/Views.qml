import QtQuick

Item {
    property alias gridView: _gridView
    property alias singleView: _singleView

    //singleView displays only a single picture
    Image{
        id:_singleView
        anchors.fill:parent
    }
    //浏览多张图片视图
    GridView {
        id:_gridView
        anchors.fill: parent
    }
}