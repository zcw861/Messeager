/*  The content component of the freepv appwindow.
 *  Author: stardust
 *  Data: 2026-06-01
**/
import QtQuick
import QtQuick.Dialogs
import QtQuick.Controls

//窗口的内容组件
Item{
    property alias dialogs: _dialogs
    property alias gridView: _views.gridView
    property alias singleView: _views.singleView

    property bool isFullScreen: false



    //setting the logic of all dialogs
    Dialogs{
        id:_dialogs
    }

    Views{
        id: _views
        anchors.fill: parent
    }




}

