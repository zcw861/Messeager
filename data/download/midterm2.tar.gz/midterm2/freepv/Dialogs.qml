/* Here are all dialogs's UIs in freepv.
 *  Author: stardust
 *  Data: 2026-06-15
**/
import QtQuick
import QtCore
import QtQuick.Controls
import QtQuick.Dialogs

Item {
    property alias fileOpen: _fileOpen
    property alias about: _about

    FileDialog {
        id: _fileOpen
        title: "Select some picture files"
        currentFolder: StandardPaths.writableLocation(StandardPaths.PicturesLocation)
        fileMode: FileDialog.OpenFiles
        nameFilters: [ "Image files (*.png *.jpeg *.jpg)" ]
    }

    MessageDialog{
        id:_about
        modality: Qt.WindowModal
        buttons:MessageDialog.Ok
        text:"Freepv – a simple picture viewer"
        informativeText: qsTr("Freepv is a free software, and you can download its source code from www.open-src.com")
        detailedText: "Copyright©2026 Wei Gong (open-src@qq.com)"
    }
}


